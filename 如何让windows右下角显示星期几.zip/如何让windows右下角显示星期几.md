* 打开控制面板——更改日期、时间或者数字格式

![](images/image-4.png)

* 进入其他设置

![](images/image-3.png)

进入日期——加上ddd或者dddd

![](images/image-1.png)

![dddd显示的是星期几](images/image-2.png)

![ddd显示的是周几](images/image.png)

